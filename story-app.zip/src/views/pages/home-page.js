// src/views/pages/home-page.js

import L from 'leaflet'; // Impor Leaflet
import ApiService from '../../api/api-service';
import Auth from '../../utils/auth';

const HomePage = {
  async render() {
    // Layout untuk daftar cerita dan peta (Kriteria 4 Responsif)
    return `
      <div class="home-container">
        <div class="story-list-container">
          <h1>Daftar Cerita</h1>
          <div id="story-list-content" class="story-list-content">
            <p>Memuat cerita...</p>
            </div>
        </div>
        <div class="map-container">
          <div id="map" tabindex="-1"></div> 
          </div>
      </div>
    `;
  },

  async afterRender() {
    const token = Auth.getToken();
    if (!token) {
      console.error('Token tidak ditemukan, gagal memuat data.');
      return;
    }

    const storyListContent = document.getElementById('story-list-content');
    const mapElement = document.getElementById('map');

    if (!mapElement) {
      console.error('Elemen #map tidak ditemukan!');
      return;
    }

    // 1. Inisialisasi Peta Leaflet (Kriteria 2)
    const map = L.map('map').setView([-2.5489, 118.0149], 5);

    // --- Kriteria 2 (Advance): Multiple Tile Layers ---
    const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    });
    const openTopo = L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
      attribution: 'Map data: &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, <a href="http://viewfinderpanoramas.org">SRTM</a> | Map style: &copy; <a href="https://opentopomap.org">OpenTopoMap</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)'
    });
    const esriSatellite = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
      attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
    });

    osm.addTo(map);

    const baseLayers = {
      "OpenStreetMap": osm,
      "OpenTopoMap": openTopo,
      "Satelit (ESRI)": esriSatellite,
    };
    L.control.layers(baseLayers).addTo(map);

    const markers = {};

    try {
      // 2. Ambil Data Cerita dari API
      const stories = await ApiService.getStories(token);

      if (stories.length === 0) {
        storyListContent.innerHTML = '<p>Belum ada cerita untuk ditampilkan.</p>';
        return;
      }

      storyListContent.innerHTML = '';

      // 3. Render Setiap Cerita ke Daftar dan Peta
      stories.forEach((story) => {
        if (story.lat && story.lon) {
          // --- Render ke Daftar List ---
          const storyItem = document.createElement('div');
          storyItem.className = 'story-item';
          storyItem.setAttribute('role', 'button');
          storyItem.setAttribute('tabindex', '0');
          storyItem.setAttribute('data-id', story.id); 
          storyItem.innerHTML = `
            <img src="${story.photoUrl}" alt="Foto oleh ${story.name}">
            <div class="story-item-info">
              <h2>${story.name}</h2>
              <p>${story.description.substring(0, 100)}...</p>
              <small class="story-date">
                ${new Date(story.createdAt).toLocaleDateString()}
              </small>
            </div>
          `;
          storyListContent.appendChild(storyItem);

          // --- Render ke Peta (Marker & Popup) ---
          const marker = L.marker([story.lat, story.lon]).addTo(map);
          marker.bindPopup(`
            <b>${story.name}</b><br>
            <img src="${story.photoUrl}" alt="Foto oleh ${story.name}" width="100"><br>
            ${story.description.substring(0, 50)}...
          `);
          markers[story.id] = marker;
        }
      });

      // Fungsi helper HANYA untuk logika peta (flyTo dan buka popup)
      function handleStoryItemClick(storyId) {
        const marker = markers[storyId];
        if (marker) {
          map.flyTo(marker.getLatLng(), 15);
          marker.openPopup();
        }
      }

      // Listener untuk KLIK MOUSE (TERPISAH)
      storyListContent.addEventListener('click', (event) => {
        const storyItem = event.target.closest('.story-item');
        if (!storyItem) return;

        // Panggil helper (HANYA logika peta)
        handleStoryItemClick(storyItem.getAttribute('data-id'));
      });

      // Listener untuk KEYBOARD (TERPISAH)
      storyListContent.addEventListener('keydown', (event) => {
        // Cek jika tombol 'Enter' (13) atau 'Space' (32) ditekan
        if (event.keyCode === 13 || event.keyCode === 32) {
          event.preventDefault(); // Hentikan scroll jika 'Space' ditekan
          const storyItem = event.target.closest('.story-item');
          if (!storyItem) return;
          
          // 1. Panggil helper untuk logika peta
          handleStoryItemClick(storyItem.getAttribute('data-id'));
          
          // 2. Pindahkan fokus keyboard ke peta (HANYA saat pakai keyboard)
          document.getElementById('map').focus();
        }
      });

    } catch (error) {
      storyListContent.innerHTML = `<p class="error-message">${error.message}</p>`;
    }
  },
};

export default HomePage;