import './style.css';
import 'leaflet/dist/leaflet.css';

import Router from './utils/router';
import LoginPage from './views/pages/login-page';
import RegisterPage from './views/pages/register-page';
import HomePage from './views/pages/home-page';
import LogoutPage from './views/pages/logout-page';
import AddStoryPage from './views/pages/add-story-page';

import Auth from './utils/auth';

if (!document.startViewTransition) {
  document.startViewTransition = (callback) => {
    callback(); // Langsung jalankan callback tanpa transisi
  };
}

function updateNavigationUI() {
  const navElement = document.querySelector('.app-nav ul');
  if (!navElement) return;

  if (Auth.isLoggedIn()) {
    // Pengguna sudah login
    navElement.innerHTML = `
      <li><a href="#/home">Home</a></li>
      <li><a href="#/add-story">Tambah Cerita</a></li>
      <li><a href="#/logout">Logout</a></li>
    `;
  } else {
    // Pengguna belum login
    navElement.innerHTML = `
      <li><a href="#/login">Login</a></li>
      <li><a href="#/register">Register</a></li>
    `;
  }
}

/**
 * Melindungi Rute
 * @returns {boolean} True jika diizinkan, false jika ditolak
 */
function handleAuthRoutes() {
  const path = window.location.hash;
  const isLoggedIn = Auth.isLoggedIn();

  const authRoutes = ['#/home', '#/add-story'];
  const guestRoutes = ['#/login', '#/register'];

  if (isLoggedIn && guestRoutes.includes(path)) {
    // Jika sudah login tapi akses halaman login/register, redirect ke home
    window.location.hash = '#/home';
    return false;
  }

  if (!isLoggedIn && authRoutes.includes(path)) {
    // Jika belum login tapi akses halaman home/add, redirect ke login
    window.location.hash = '#/login';
    return false;
  }

  return true;
}

// Fungsi untuk inisialisasi aplikasi
function initApp() {
  const appContent = document.getElementById('app-content');
  if (!appContent) {
    console.error('Elemen #app-content tidak ditemukan!');
    return;
  }

  const skipLink = document.querySelector('.skip-link');
  skipLink.addEventListener('click', (event) => {
    // 1. Hentikan aksi default (yaitu MENGUBAH HASH URL)
    event.preventDefault();
    
    // 2. Lakukan aksi yang seharusnya: pindahkan fokus ke target
    appContent.focus();
  });
  
  // Update UI Navigasi saat pertama kali load
  updateNavigationUI();

  // Setiap kali hash berubah, cek otentikasi dan update nav
  window.addEventListener('hashchange', () => {
    handleAuthRoutes();
    updateNavigationUI();
  });
  
  // Cek otentikasi saat load awal
  if (!handleAuthRoutes()) {
     // Jika redirect terjadi, hentikan inisialisasi router
     // Biarkan hashchange handler yang mengambil alih
     return;
  }

  const router = new Router(appContent);
  router.addRoute('#/login', LoginPage);
  router.addRoute('#/register', RegisterPage);
  router.addRoute('#/home', HomePage);
  router.addRoute('#/logout', LogoutPage);
  router.addRoute('#/add-story', AddStoryPage);

  // Handle rute default/kosong
  if (window.location.hash === '') {
    window.location.hash = Auth.isLoggedIn() ? '#/home' : '#/login';
  }

  // Panggil router handle secara manual setelah setup
  router.handleRouteChange();
}

// Jalankan aplikasi saat DOM sudah siap
document.addEventListener('DOMContentLoaded', initApp);